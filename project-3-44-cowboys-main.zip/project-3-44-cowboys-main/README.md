Deployment website: https://panda-pos-ten.vercel.app/
Pins:
   1234 - Managers (Harsh Dave)
   0000 - Customer
   1111 - Menu Boards
   5389 - Cashier View (Austin Rummel)
   3333 - Kitchen View 